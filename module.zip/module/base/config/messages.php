<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 1/3/2018
 * Time: 11:30 AM
 */
return [
	'success_edit' => 'Cập nhật bản ghi thành công',
	'success_delete' => 'Xóa bản ghi thành công',
	'success_create' => 'Tạo bản ghi mới thành công',
	'error' => 'Có lỗi xảy ra, vui lòng kiểm tra lại dữ liệu nhập vào',
	'role_error' => 'Vai trò này đang được áp dụng, Hãy gỡ vai trò này ra khỏi tài khoản rồi xóa lại'
];