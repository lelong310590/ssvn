<li class="nav-item">
	<a class="nav-link" href="{{route('nqadmin::subject.index.get')}}">
		Chứng chỉ <span class="badge badge-danger ml-2"></span>
	</a>
</li>