<li class="nav-item">
	<a class="nav-link" href="{{ route('nqadmin::classlevel.index.get') }}">
		Công ty <span class="badge badge-danger ml-2"></span>
	</a>
</li>