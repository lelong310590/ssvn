<li class="nav-item">
	<a class="nav-link" href="{{ route('nqadmin::pricetier.index.get') }}">
		Giá Khóa đào tạo<span class="badge badge-danger ml-2"></span>
	</a>
</li>