<?php

namespace Course\Models;

use Illuminate\Database\Eloquent\Model;

class CourseCurriculumItemReport extends Model
{
    protected $table = 'course_curriculum_items_reports';
}