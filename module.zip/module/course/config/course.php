<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 4/9/2018
 * Time: 2:20 PM
 */
return [
	'target_ph_1' => 'Ví dụ: Có thể đọc được bản nhạc và làm quen với các thuật ngữ lý thuyết âm nhạc. Một cây đàn piano là tùy chọn.',
	'target_ph_2' => 'Ví dụ: Các nhà phát triển python mới bắt đầu tò mò về khoa học dữ liệu. Khóa đào tạonày không dành cho các nhà khoa học dữ liệu có kinh nghiệm.',
	'target_ph_3' => 'Ví dụ: chụp ảnh tuyệt vời ngay cả trong ánh sáng thấp.'
];