<div class="top-left">
    <div class="row">
        <div class="col-xs-6">
            <div class="pull-left">
                <div class="box-dropdown-single">
                    <div class="dropdown-single">
                        <span class="show-txt">Tất cả tin nhắn <i class="fas fa-chevron-down pull-right"></i></span>
                        <ul class="form-dropdown">
                            <li><a href="#" class="active">Tất cả tin nhắn</a></li>
                            <li><a href="#">Tin chưa đọc</a></li>
                            <li><a href="#">Tin đã gửi</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        {{--<div class="col-xs-6">--}}
            {{--<div class="pull-right">--}}
                {{--<div class="icon-toggle">--}}
                    {{--<input class="" id="btn-toggle" type="checkbox">--}}
                    {{--<label class="btn-toggle" for="btn-toggle">--}}
                        {{--<span class="text-1 pull-left">Hiển thị thư tự động</span>--}}
                        {{--<span class="icon overflow"></span>--}}
                    {{--</label>--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
        <div class="col-xs-12">
            <div class="box-search-left box-search">
                <div class="form-group">
                    <input type="search" class="txt-form" placeholder="Tìm kiếm tên">
                    <button type="submit" class="btn btn-search">
                        <i class="fa fa-search" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>