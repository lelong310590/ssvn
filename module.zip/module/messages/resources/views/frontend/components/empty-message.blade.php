<div class="main-right">
    <div class="top top-main-right row">
        <div class="left col-xs-9 pull-left">
            <div class="box-img pull-left ">
                <a href="#" class="img pull-left img-circle">
                    @include('nqadmin-users::frontend.components.user.thumbnail',['user'=>$temp_user])
                </a>
            </div>
            <div class="main pull-left">
                <h4 class="name"><a href="#">{{ $temp_user->first_name }}</a></h4>
            </div>
        </div>

        <div class="right col-xs-3 ">
            <div class="pull-right">
                <div class="pull-left favorite-message favorite">
                    <i class="fas fa-star"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="main-right-message">
        <div class="list-message your-message">
            <div class="main">
                <div class="content">
                    <p>Welcome. Welcome to your online Java online of the Nguyen Thanh Tuyền. Cám ơn bạn đã
                        tham dự Khóa đào tạocủa mình. Mình hi vọng you have the following good results that the
                        following key for the server for the destination entries on fields and go your your friend,</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message me-message">
            <div class="main">
                <div class="content">
                    <p>Khóa đào tạorất dễ hiểu, chỉ dạy tận tình</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message me-message">
            <div class="main">
                <div class="content">
                    <p>Sau Khóa đào tạonày, e muốn theo học các khóa nâng cao hơn.</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message your-message">
            <div class="main">
                <div class="content">
                    <p>Welcome. Welcome to your online Java online of the Nguyen Thanh Tuyền. Cám ơn bạn đã
                        tham dự Khóa đào tạocủa mình. Mình hi vọng you have the following good results that the
                        following key for the server for the destination entries on fields and go your your friend,</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message me-message">
            <div class="main">
                <div class="content">
                    <p>Khóa đào tạorất dễ hiểu, chỉ dạy tận tình</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message me-message">
            <div class="main">
                <div class="content">
                    <p>Sau Khóa đào tạonày, e muốn theo học các khóa nâng cao hơn.</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message your-message">
            <div class="main">
                <div class="content">
                    <p>Welcome. Welcome to your online Java online of the Nguyen Thanh Tuyền. Cám ơn bạn đã
                        tham dự Khóa đào tạocủa mình. Mình hi vọng you have the following good results that the
                        following key for the server for the destination entries on fields and go your your friend,</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message me-message">
            <div class="main">
                <div class="content">
                    <p>Khóa đào tạorất dễ hiểu, chỉ dạy tận tình</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message me-message">
            <div class="main">
                <div class="content">
                    <p>Sau Khóa đào tạonày, e muốn theo học các khóa nâng cao hơn.</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message your-message">
            <div class="main">
                <div class="content">
                    <p>Welcome. Welcome to your online Java online of the Nguyen Thanh Tuyền. Cám ơn bạn đã
                        tham dự Khóa đào tạocủa mình. Mình hi vọng you have the following good results that the
                        following key for the server for the destination entries on fields and go your your friend,</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message me-message">
            <div class="main">
                <div class="content">
                    <p>Khóa đào tạorất dễ hiểu, chỉ dạy tận tình</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>

        <div class="list-message me-message">
            <div class="main">
                <div class="content">
                    <p>Sau Khóa đào tạonày, e muốn theo học các khóa nâng cao hơn.</p>
                </div>
                <div class="bottom clearfix">
                    <span class="day pull-left">16 ngày trước</span>
                    <a href="#report-box" class="report pull-right btn-popup"><i class="fas fa-flag"></i></a>
                </div>
            </div>
        </div>
    </div>

    <div class="form-message">
        <div class="form-group">
            <input class="form-input" placeholder="Viết bình luận của bạn">
            <input type="button" value="Gửi tin" class="btn-default-white btn btn-small btn-send">
        </div>
    </div>
</div>