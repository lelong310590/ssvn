<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 8/8/2018
 * Time: 9:52 AM
 */
if (!function_exists('recursive_menu_node')) {
    /**
     * @return bool
     */
    function recursive_menu_node()
    {

    }
}