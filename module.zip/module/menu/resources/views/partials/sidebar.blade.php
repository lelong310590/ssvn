{{--@php--}}
{{--    $listRoute = [--}}
{{--        'nqadmin::menu.list.get', 'nqadmin::menu.index.get', 'nqadmin::menu.create.get', 'nqadmin::menu.edit.get',--}}
{{--        'nqadmin::menu-node.edit.get'--}}
{{--    ];--}}

{{--@endphp--}}
{{--<li class="nav-item {{in_array(Route::currentRouteName(), $listRoute) ? 'active' : '' }}">--}}
{{--    <a href="{{route('nqadmin::menu.index.get')}}" class="nav-link {{in_array(Route::currentRouteName(), $listRoute) ? 'active' : '' }}">--}}
{{--        <i class="fa fa-bars" aria-hidden="true"></i> Menu--}}
{{--    </a>--}}
{{--</li>--}}