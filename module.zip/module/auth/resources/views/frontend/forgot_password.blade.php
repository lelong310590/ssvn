<form action="" method="post" role="form">
	<legend>Quên mật khẩu</legend>
	
	<div class="form-group">
		<label for=""></label>
		<input type="text" class="form-control" name="" id="" placeholder="Input...">
	</div>
	
	
	
	<button type="submit" class="btn btn-primary">Submit</button>
</form>