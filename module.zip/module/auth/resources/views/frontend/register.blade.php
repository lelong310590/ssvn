<form action="" method="post" role="form">
	<legend>Register</legend>
	
	<div class="form-group">
		<label for=""></label>
		<input type="text" class="form-control" name="" id="" placeholder="Input...">
	</div>
	
	<div class="form-group">
		<label for=""></label>
		<input type="text" class="form-control" name="" id="" placeholder="Input...">
	</div>
	
	<button type="submit" class="btn btn-primary">Register</button>
</form>